# BioNexa — Biomedical Engineering Companion

BioNexa is an offline-first Android study companion built with Vite and Capacitor. The Android app name is **BioNexa** and the custom scientific engineering icon is in `assets/icon.png`.

## Included
- Searchable bundled starter reference library for physics, chemistry, mathematics, engineering and biomedical engineering
- Ohm’s law, electrical power and pressure conversion calculators
- On-device notes and study planner (saved locally on the device)
- A basic one-question quiz and a limited offline explanation helper
- Online Gemini AI tutor using the API key supplied by the project owner (requires internet)
- “Welcome Boss!” spoken greeting where Android WebView supports speech synthesis
- Custom BioNexa launcher icon

The reference library is a starter collection, not literally every scientific law. Verify equations, assumptions and units against course materials. Online Gemini AI is connected directly from the app using the owner-provided key. This is convenient for a personal prototype, but the key is embedded in source and the APK and can be extracted by anyone who obtains the APK. Keep the repository private, do not share the APK publicly, and rotate the key if it is exposed. For a public release, replace this direct connection with a protected backend or Firebase AI Logic and App Check: https://firebase.google.com/docs/ai-logic/get-started

## Build the APK using GitHub Actions (no computer required)
1. Extract this ZIP on your phone.
2. In your GitHub repository `project-17c-android`, upload **all files and folders inside this ZIP** to the repository root (not the outer ZIP folder). Keep folder paths exactly as shown. Commit to the `main` branch.
3. Open the repository’s **Actions** tab and select **Build BioNexa Android APK**. If needed, choose **Run workflow**.
4. Wait for the workflow to finish with a green check mark. Open that run and download the artifact named **BioNexa-Android-APK**.
5. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from your browser or file manager. Only install the APK you built from your own repository.

## What the workflow does
Installs Node.js and Java, builds the web app, creates the Android project, applies the BioNexa icon and app label, compiles a debug APK, and uploads the APK as an artifact. The first build may take several minutes. A successful build cannot be guaranteed until GitHub Actions completes successfully.
